import ReactDOM from 'react-dom';
import './index.scss';
import {App} from './App';

import './models/init'

ReactDOM.render(
    <App />,
  document.getElementById('root')
);

