import React from 'react';
import styled from 'styled-components'
import { ConfigNode } from '../../types';

// @ts-ignore
import { JsonEditor } from 'jsoneditor-react'


const mock: ConfigNode[] = [
  {
    createdIndex: 0,
    key: "/test",
    modifiedIndex: 0,
    value: "{\"test\":123,\"test_obj\":{\"key_1\":[\"apples\",\"bananas\",\"grapes\"]}}",
  },
  {
    createdIndex: 1,
    key: "/test_2",
    modifiedIndex: 1,
    value: "{\"test\":234,\"test_obj\":{\"key_1\":[\"apples\",\"bananas\",\"grapes\"]}}",
  },
  {
    createdIndex: 2,
    key: "/test_3",
    modifiedIndex: 2,
    value: "{\"test\":345,\"test_obj\":{\"key_1\":[\"apples\",\"bananas\",\"grapes\"]}}",
  },
]

const editorOptions = {
  modes: ['code', 'text', 'tree', 'view']
}


export const Editor = () => {

  const saveConfig = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault()
    console.log('Save config');
  }
  const cancel = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault()
    console.log('Cancel')
  }

  return (
  <Form 
    className="editor-form"
  >
      <JsonEditor
        value={JSON.parse(mock[0].value)}
        schema={editorOptions.modes}
      />
    <ActionContainer className="action-container">
      <Button
        onClick={cancel}
      >
        Cancel
      </Button>
      <Button
        onClick={saveConfig}
      >
        Save config
      </Button>
    </ActionContainer>
  </Form>
  );
};

const Form = styled.form`
  height: 100%;
  display: flex;
  flex-direction: column;
  position: relative;
`
const ActionContainer = styled.div`
  position: absolute;
  display: flex;
  bottom: 46px;
  right: 20px;
`
const Button = styled.button`
  padding: 0 10px;
  height: 30px;
  display: inline-flex;
  align-items: center;
`


