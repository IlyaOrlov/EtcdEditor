import React, { FC } from 'react';
import { ConfigNode } from '../../types';
import styled from 'styled-components'

const mock: ConfigNode[] = [
  {
    createdIndex: 0,
    key: "/test",
    modifiedIndex: 0,
    value: "{\"test\":123,\"test_obj\":{\"key_1\":[\"apples\",\"bananas\",\"grapes\"]}}",
  },
  {
    createdIndex: 1,
    key: "/test_2",
    modifiedIndex: 1,
    value: "{\"test\":234,\"test_obj\":{\"key_1\":[\"apples\",\"bananas\",\"grapes\"]}}",
  },
  {
    createdIndex: 2,
    key: "/test_3",
    modifiedIndex: 2,
    value: "{\"test\":345,\"test_obj\":{\"key_1\":[\"apples\",\"bananas\",\"grapes\"]}}",
  },
]

export const NodesTree: FC = () => {

  const [childNodes, setChildNodes] = React.useState(mock);
  const [selectedNodesKeys, setSelectedNodesKeys] = React.useState(new Set());
  const [isFormOpened, setIsFormOpened] = React.useState(false);
  const [nodeName, setNodeName] = React.useState('');

  const openForm = () => {
    setIsFormOpened(true)
  }

  const addNewNode = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault()
    console.log('Add New Node', nodeName);
    setChildNodes([
      ...childNodes,
      {
        createdIndex: childNodes.length,
        key: nodeName,
        modifiedIndex: childNodes.length,
        value: "",
      }
    ])
    setNodeName('')
    setIsFormOpened(false)
  }
  const cancel = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    e.preventDefault()
    console.log('Cancel')
    setNodeName('')
    setIsFormOpened(false)
  }

  const onInputHandle = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNodeName(e.target.value)
  }

  const selectNode = (node: ConfigNode) => {
    console.log(node.key)
    const newSelectgedKeys = new Set(Array.from(selectedNodesKeys))
    if (newSelectgedKeys.has(node.key)) {
      newSelectgedKeys.delete(node.key)
    } else {
      newSelectgedKeys.add(node.key)
    }
    setSelectedNodesKeys(newSelectgedKeys)
  }

  return (
    <>
      {
        childNodes.length > 0 && (
          <div className="nodes">
            {
              childNodes.map(node => (
                <NodesItem
                  key={node.key}
                  active={selectedNodesKeys.has(node.key)}
                  onClick={() => selectNode(node)}
                >
                  {node.key}
                </NodesItem>
            ))
          }
          </div>
        )
      }

      <div className="add-form">
        {
          !isFormOpened && (
            <button onClick={openForm}>
              Add item
            </button>
          )
        }
        {
          isFormOpened && (
            <form>
              <div>
                <label htmlFor="node_name">Key name</label>
                <input
                  onChange={onInputHandle}
                  id="node_name"
                  name="node_name"
                  value={nodeName}
                  placeholder="key"
                />
              </div>
              <div className="actions">
                <button onClick={addNewNode} className="save-button">
                  Save
                </button>
                <button onClick={cancel} className="cancel-button">
                  Cancel
                </button>
              </div >
            </form >
          )
        }
      </div >

    </>
  );
};

interface Props {
  key: string,
  active: boolean,
  onClick: any
}

const NodesItem = styled.button<Props>`
  background: ${props => props.active ? "lightblue" : "" }
`
