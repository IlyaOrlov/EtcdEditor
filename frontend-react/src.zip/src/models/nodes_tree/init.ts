export function func() {
  console.log(222)
}