import React from 'react';
import styled from 'styled-components';

import './models/init'

import {NodesTree} from '../src/models/nodes_tree'
import {Editor} from '../src/models/editor'

export function App() {
  return (
  <Container>
    <Sidebar>
      <SidebarHeader>Config Editor</SidebarHeader>
      <SidebarContent>
        <NodesTree />
      </SidebarContent>
    </Sidebar>
    <Main>
        <Editor />
    </Main>
  </Container >
  );
}

const Container = styled.div`
  width: 100%;
  height: 100%;
  display: grid;
  grid-template-areas: "sidebar main";
  grid-template-columns: 300px auto;
  & > * {
    padding: 10px;
  }
`
const Sidebar = styled.div`
  grid-area: sidebar;
  background-color: #fff;
  border: 1px solid #3883fa;
  border-right-width: 0px;
`
const SidebarHeader = styled.div`
  background-color: #3883fa;
  font-size: 14px;
  color: #ffffffbf;
`
const SidebarContent = styled.div`

`
const Main = styled.main`
  grid-area: main;
  height: 100%;
  background-color: gray;
`
